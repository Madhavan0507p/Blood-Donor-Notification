<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "person_db";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$donors = [];

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['blood_group'])) {
    $blood_group = $_POST['blood_group'];

    $sql = "SELECT * FROM donors WHERE blood_group = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $blood_group);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $donors[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Need Blood</title>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <style>
    /* ====== Global Styles ====== */
    body {
      font-family: 'Poppins', Arial, sans-serif;
      background: linear-gradient(135deg, #ffe5e5, #ffffff);
      margin: 0;
      padding: 30px 15px;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      transition: background 0.6s ease;
    }

    h2 {
      text-align: center;
      color: #d9534f;
      font-size: 28px;
      letter-spacing: 1px;
      margin-bottom: 25px;
      text-shadow: 0px 2px 4px rgba(0,0,0,0.1);
    }

    /* ====== Form Styling ====== */
    form {
      background: #fff;
      padding: 25px;
      border-radius: 16px;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
      width: 100%;
      max-width: 420px;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    form:hover {
      transform: scale(1.02);
      box-shadow: 0 15px 30px rgba(217, 83, 79, 0.3);
    }

    label {
      font-weight: 600;
      color: #333;
      font-size: 15px;
    }

    select, button {
      width: 100%;
      padding: 12px;
      margin-top: 12px;
      border: 1px solid #ccc;
      border-radius: 8px;
      font-size: 16px;
      outline: none;
      transition: all 0.3s ease;
    }

    select:focus {
      border-color: #d9534f;
      box-shadow: 0 0 8px rgba(217, 83, 79, 0.3);
    }

    button {
      background: linear-gradient(90deg, #d9534f, #ff6b6b);
      color: white;
      cursor: pointer;
      font-weight: bold;
      border: none;
      transition: all 0.3s ease-in-out;
      letter-spacing: 0.5px;
    }

    button:hover {
      background: linear-gradient(90deg, #ff6b6b, #d9534f);
      box-shadow: 0 4px 12px rgba(217, 83, 79, 0.4);
      transform: translateY(-2px);
    }

    /* ====== Table Styling ====== */
    table {
      width: 100%;
      margin-top: 25px;
      border-collapse: collapse;
      background: #fff;
      border-radius: 16px;
      overflow: hidden;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
      animation: fadeIn 0.8s ease;
    }

    table, th, td {
      border: 1px solid #eee;
    }

    th, td {
      padding: 14px;
      text-align: left;
    }

    th {
      background: linear-gradient(90deg, #d9534f, #ff6b6b);
      color: white;
      font-weight: 600;
      text-transform: uppercase;
      font-size: 14px;
      letter-spacing: 0.5px;
    }

    tr:nth-child(even) {
      background-color: #fafafa;
    }

    tr:hover {
      background-color: #ffecec;
      transition: background 0.3s ease;
    }

    /* ====== Buttons under table ====== */
    .btn-container {
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
      gap: 12px;
      margin-top: 25px;
      text-align: center;
    }

    .btn-container button {
      width: 180px;
      padding: 12px;
      font-size: 15px;
      border-radius: 8px;
      background: linear-gradient(90deg, #d9534f, #ff6b6b);
      color: white;
      font-weight: 600;
      border: none;
      cursor: pointer;
      transition: all 0.3s ease;
      text-align: center;
    }

    .btn-container button:hover {
      background: linear-gradient(90deg, #ff6b6b, #d9534f);
      transform: scale(1.05);
      box-shadow: 0 4px 12px rgba(217, 83, 79, 0.4);
    }

    /* ====== Animations ====== */
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(10px); }
      to { opacity: 1; transform: translateY(0); }
    }

    /* ====== Responsive Design ====== */
    @media (max-width: 768px) {
      form {
        width: 90%;
      }

      table th, table td {
        font-size: 14px;
      }

      .btn-container button {
        width: 100%;
      }
    }
  </style>

  <script>
    function sendMessage(donorId, mobileNumber) {
      let messageContent = prompt("Enter your message:");

      if (messageContent === null || messageContent.trim() === "") {
          alert("Message cannot be empty.");
          return;
      }

      $.ajax({
          url: "send_message.php",
          type: "POST",
          data: {
              donor_id: donorId,
              mobile: mobileNumber,
              message: messageContent
          },
          success: function(response) {
              console.log("Server Response:", response);
              if (response.includes("Message sent successfully")) {
                  alert("Message sent successfully!");
              } else {
                  alert("Failed to send message: " + response);
              }
          },
          error: function(xhr, status, error) {
              console.log("AJAX Error:", error);
              alert("Failed to send message due to an error.");
          }
      });
    }
  </script>
</head>

<body>
  <h2>Search Blood Donors</h2>

  <form method="POST">
      <label>Blood Group:</label>
      <select name="blood_group" required>
          <option value="">Select</option>
          <option value="A+">A+</option>
          <option value="A-">A-</option>
          <option value="B+">B+</option>
          <option value="B-">B-</option>
          <option value="O+">O+</option>
          <option value="O-">O-</option>
          <option value="AB+">AB+</option>
          <option value="AB-">AB-</option>
      </select>
      <button type="submit">Search</button>
  </form>

  <?php if (!empty($donors)) { ?>
      <table>
          <tr>
              <th>Name</th>
              <th>Mobile</th>
              <th>Age</th>
              <th>Email</th>
              <th>Gender</th>
              <th>Blood Group</th>
              <th>Address</th>
              <th>Action</th>
          </tr>
          <?php foreach ($donors as $donor) { ?>
          <tr>
              <td><?php echo $donor['fullname']; ?></td>
              <td><?php echo $donor['mobile']; ?></td>
              <td><?php echo $donor['age']; ?></td>
              <td><?php echo $donor['email']; ?></td>
              <td><?php echo $donor['gender']; ?></td>
              <td><?php echo $donor['blood_group']; ?></td>
              <td><?php echo $donor['address']; ?></td>
              <td>
                  <button onclick="sendMessage('<?php echo $donor['id']; ?>', '<?php echo $donor['mobile']; ?>')">
                    Send Message
                  </button>
              </td>
          </tr>
          <?php } ?>
      </table>

      <div class="btn-container">
          <form action="show_location.php" method="GET">
              <input type="hidden" name="blood_group" value="<?php echo htmlspecialchars($_POST['blood_group']); ?>">
              <button type="submit">Show Location</button>
          </form>

          <form action="get_location.php" method="GET">
              <input type="hidden" name="blood_group" value="<?php echo htmlspecialchars($_POST['blood_group']); ?>">
              <button type="submit">Get Location</button>
          </form>

          <button onclick="window.history.back()">Go Back</button>
      </div>

  <?php } else if ($_SERVER["REQUEST_METHOD"] == "POST") { ?>
      <p style="text-align: center; color: red; font-weight: bold;">No donors found for the selected blood group.</p>
  <?php } ?>
</body>
</html>