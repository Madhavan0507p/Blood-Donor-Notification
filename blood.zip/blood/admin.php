<?php
session_start();
$conn = new mysqli("localhost", "root", "", "person_db");
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

$admin_user = "admin";
$admin_pass = "123";

// Login
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    if ($username === $admin_user && $password === $admin_pass) {
        $_SESSION['admin_logged_in'] = true;
    } else {
        $error = "Invalid username or password!";
    }
}

// Logout
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: admin.php");
    exit;
}

// If not logged in, show login page
if (!isset($_SESSION['admin_logged_in'])) {
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin Login</title>
<style>
    body {
        margin: 0;
        padding: 0;
        background: linear-gradient(135deg, #ef4c51ff, #e3595eff);
        font-family: Arial, sans-serif;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }

    .login-box {
        background: rgba(233, 76, 76, 0.32);
        backdrop-filter: blur(10px);
        padding: 30px;
        width: 350px;
        border-radius: 15px;
        box-shadow: 0 8px 25px rgba(0,0,0,0.3);
        color: white;
        text-align: center;
        animation: fadeIn 0.7s ease;
        border: 2px solid rgba(133, 53, 53, 0.2);
    }

    h2 { margin-bottom: 15px; }

    input {
        width: 90%;
        padding: 12px;
        border-radius: 8px;
        border: none;
        margin: 10px 0;
        outline: none;
    }

    button {
        width: 95%;
        padding: 12px;
        border-radius: 8px;
        background: linear-gradient(135deg, #d63031, #b32425);
        color: white;
        border: none;
        cursor: pointer;
        transition: 0.3s;
        font-size: 16px;
    }

    button:hover {
        transform: scale(1.05);
        box-shadow: 0 8px 20px rgba(214,48,49,0.6);
    }

    p { color: #ffbaba; }

    @keyframes fadeIn {
        from {opacity: 0; transform: translateY(20px);}
        to {opacity: 1; transform: translateY(0);}
    }
</style>
</head>

<body>
<div class="login-box">
    <h2>Admin Login</h2>
    <form method="post">
        <input type="text" name="username" placeholder="Enter Username" required>
        <input type="password" name="password" placeholder="Enter Password" required>
        <button type="submit" name="login">Login</button>
    </form>
    <?php if(isset($error)) echo "<p>$error</p>"; ?>
</div>
</body>
</html>
<?php
    exit;
}

// Add Donor
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_donor'])) {
    $fullname = $_POST['fullname'];
    $mobile = $_POST['mobile'];
    $age = $_POST['age'];
    $email = $_POST['email'];
    $blood_group = $_POST['blood_group'];
    $address = $_POST['address'];
    $latitude = $_POST['latitude'];
    $longitude = $_POST['longitude'];

    if (!empty($latitude) && !empty($longitude)) {
        $stmt = $conn->prepare("INSERT INTO donors (fullname, mobile, age, email, blood_group, address, latitude, longitude)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssisssdd", $fullname, $mobile, $age, $email, $blood_group, $address, $latitude, $longitude);
        $stmt->execute();
        header("Location: admin.php");
        exit;
    }
}

// Update Donor
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_donor'])) {
    $uid = $_POST['uid'];
    $fullname = $_POST['fullname'];
    $mobile = $_POST['mobile'];
    $age = $_POST['age'];
    $email = $_POST['email'];
    $blood_group = $_POST['blood_group'];
    $address = $_POST['address'];
    $latitude = $_POST['latitude'];
    $longitude = $_POST['longitude'];

    $stmt = $conn->prepare("UPDATE donors SET fullname=?, mobile=?, age=?, email=?, blood_group=?, address=?, latitude=?, longitude=? WHERE id=?");
    $stmt->bind_param("ssisssddi", $fullname, $mobile, $age, $email, $blood_group, $address, $latitude, $longitude, $uid);
    $stmt->execute();

    header("Location: admin.php");
    exit;
}

// Delete Donor
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $conn->query("DELETE FROM donors WHERE id=$id");
    header("Location: admin.php");
    exit;
}

// Fetch Donors
$result = $conn->query("SELECT * FROM donors");
$donors = [];
while ($row = $result->fetch_assoc()) { $donors[] = $row; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin Panel</title>
<script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
<link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />

<style>
    body {
        font-family: Arial, sans-serif;
        background: #ffe5e5;
        margin: 0;
    }

    .topbar {
        background: #d63031;
        padding: 15px;
        color: white;
        text-align: center;
        font-size: 22px;
        font-weight: bold;
        box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    }

    .container {
        width: 90%;
        margin: 25px auto;
        background: white;
        padding: 25px;
        border-radius: 12px;
        box-shadow: 0 5px 20px rgba(0,0,0,0.15);
    }

    h3 {
        border-left: 5px solid #d63031;
        padding-left: 8px;
        color: #b32425;
    }

    form input, form select {
        width: 30%;
        padding: 10px;
        margin: 8px;
        border-radius: 6px;
        border: 1px solid #ffadad;
    }

    form button {
        padding: 10px 15px;
        background: #d63031;
        color: white;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        transition: 0.3s;
    }

    form button:hover {
        background: #b32425;
        transform: scale(1.03);
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 25px;
    }

    th {
        background: #d63031;
        color: white;
        padding: 12px;
    }

    td {
        padding: 10px;
        border-bottom: 1px solid #ffcccc;
    }

    tr:hover {
        background: #ffecec;
    }

    .delete-btn {
        background: #d63031;
        padding: 8px 13px;
        color: white;
        border-radius: 5px;
        text-decoration: none;
        transition: 0.2s;
        display: inline-block;
        margin-top: 4px;
    }

    .delete-btn:hover {
        background: #b32425;
    }

    .edit-btn {
        background: #d63031;
        padding: 8px 13px;
        color: white;
        border-radius: 5px;
        text-decoration: none;
        transition: 0.2s;
        display: inline-block;
        margin-top: 4px;
    }

    .edit-btn:hover {
        background: #b32425;
    }

    #map {
        height: 400px;
        width: 100%;
        margin-top: 20px;
        border-radius: 12px;
        box-shadow: 0 8px 20px rgba(0,0,0,0.2);
    }

    .logout {
        background: #d63031;
        padding: 10px 15px;
        color: white;
        border-radius: 6px;
        text-decoration: none;
        margin-bottom: 15px;
        display: inline-block;
        transition: 0.2s;
    }

    .logout:hover {
        background: #b32425;
    }

    /* Edit Modal */
    .modal {
        position: fixed;
        inset: 0;
        background: rgba(0,0,0,0.6);
        display: none;
        justify-content: center;
        align-items: center;
        backdrop-filter: blur(4px);
        z-index: 999;
    }

    .modal-content {
        background: #ffe5e5;
        padding: 25px;
        width: 400px;
        border-radius: 12px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.3);
        animation: pop 0.3s ease;
        border-left: 6px solid #d63031;
    }

    .modal-content h2 {
        margin: 0 0 15px 0;
        color: #b32425;
    }

    .modal-content input,
    .modal-content select {
        width: 50%;
        padding:10px;
        border-radius: 6px;
        border: 1px solid #ffadad;
        margin-bottom: 10px;

    
    }

    .save-btn {
        background: #d63031;
        color: white;
        padding: 10px;
        width: 100%;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-size: 15px;
    }

    .save-btn:hover {
        background: #b32425;
    }

    .close-btn {
        background: #555;
        color: white;
        padding: 10px;
        width: 100%;
        margin-top: 8px;
        border: none;
        border-radius: 6px;
        cursor: pointer;
    }
    

    @keyframes pop {
        from {transform: scale(0.8); opacity: 0;}
        to   {transform: scale(1); opacity: 1;}
    }
</style>
</head>

<body>

<div class="topbar">Admin Panel – Donor Management</div>

<div class="container">

    <a href="admin.php?logout=true" class="logout">Logout</a>

    <h3>Add Donor</h3>

    <form method="post">
        <input type="text" name="fullname" placeholder="Full Name" required>
        <input type="text" name="mobile" placeholder="Mobile" required>
        <input type="number" name="age" placeholder="Age" required>
        <input type="email" name="email" placeholder="Email" required>

        <select  name="blood_group" required>
           <option>A+</option><option>B+</option><option>O+</option>
            <option>AB+</option><option>A-</option>
        </select>

        <input type="text" name="address" placeholder="Address" required>

        <button  class="set"type="button" onclick="openLocationPicker()">Set Location</button>

        <input type="hidden" id="latitude" name="latitude">
        <input type="hidden" id="longitude" name="longitude">

        <button type="submit" name="add_donor">Add Donor</button>
    </form>

    <h3>All Donors</h3>

    <table>
        <tr>
            <th>Name</th>
            <th>Mobile</th>
            <th>Age</th>
            <th>Email</th>
            <th>Blood Group</th>
            <th>Address</th>
            <th>Location</th>
            <th>Action</th>
        </tr>

        <?php foreach($donors as $donor): ?>
        <tr>
            <td><?= htmlspecialchars($donor['fullname']) ?></td>
            <td><?= htmlspecialchars($donor['mobile']) ?></td>
            <td><?= htmlspecialchars($donor['age']) ?></td>
            <td><?= htmlspecialchars($donor['email']) ?></td>
            <td><?= htmlspecialchars($donor['blood_group']) ?></td>
            <td><?= htmlspecialchars($donor['address']) ?></td>
            <td>(<?= $donor['latitude'] ?>, <?= $donor['longitude'] ?>)</td>
            <td>
                <button class="edit-btn" onclick="openEditModal(
                    '<?= $donor['id'] ?>',
                    '<?= htmlspecialchars($donor['fullname'], ENT_QUOTES) ?>',
                    '<?= htmlspecialchars($donor['mobile'], ENT_QUOTES) ?>',
                    '<?= $donor['age'] ?>',
                    '<?= htmlspecialchars($donor['email'], ENT_QUOTES) ?>',
                    '<?= htmlspecialchars($donor['blood_group'], ENT_QUOTES) ?>',
                    '<?= htmlspecialchars($donor['address'], ENT_QUOTES) ?>',
                    '<?= $donor['latitude'] ?>',
                    '<?= $donor['longitude'] ?>'
                )">Edit</button>
                <a href="admin.php?delete=<?= $donor['id'] ?>" class="delete-btn">Delete</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>

    <h3>Donor Locations</h3>
    <div id="map"></div>

</div>

<!-- Edit Modal -->
<div id="editModal" class="modal">
    <div class="modal-content">
        <h2>Edit Donor</h2>

        <form method="post">
            <input type="hidden" name="uid" id="edit_id">

            <input type="text" name="fullname" id="edit_fullname" placeholder="Full Name" required>
            <input type="text" name="mobile" id="edit_mobile" placeholder="Mobile" required>
            <input type="number" name="age" id="edit_age" placeholder="Age" required>
            <input type="email" name="email" id="edit_email" placeholder="Email" required>

            <select   name="blood_group" id="edit_blood" required>
                <option>A+</option><option>B+</option><option>O+</option>
                <option>AB+</option><option>A-</option>
            </select>

            <input type="text" name="address" id="edit_address" placeholder="Address" required>
            <br><br>
            <button  style="margin-left:130px"type="button" onclick="openLocationPickerForEdit()">Set New Location</button>
            <br>
            <input type="hidden" name="latitude" id="edit_latitude">
            <input type="hidden" name="longitude" id="edit_longitude">
            <br>
            <button type="submit" name="update_donor" class="save-btn">Save Changes</button>
            <button type="button" class="close-btn" onclick="closeEditModal()">Cancel</button>
        </form>
    </div>
</div>

<script>
let locationMode = "add"; // "add" or "edit"

function openLocationPicker() {
    locationMode = "add";
    window.open('location_picker.php', 'Pick Location', 'width=800,height=600');
}

function openLocationPickerForEdit() {
    locationMode = "edit";
    window.open('location_picker.php', 'Pick Location', 'width=800,height=600');
}

// Receive location from location_picker.php
window.addEventListener('message', function(event) {
    if (!event.data || typeof event.data.lat === "undefined") return;

    if (locationMode === "edit") {
        document.getElementById('edit_latitude').value = event.data.lat;
        document.getElementById('edit_longitude').value = event.data.lng;
    } else {
        document.getElementById('latitude').value = event.data.lat;
        document.getElementById('longitude').value = event.data.lng;
    }
});

var map = L.map('map').setView([20.5937, 78.9629], 5);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);

<?php foreach($donors as $donor): ?>
L.marker([<?= $donor['latitude'] ?>, <?= $donor['longitude'] ?>])
 .addTo(map)
 .bindPopup("<b><?= htmlspecialchars($donor['fullname'], ENT_QUOTES) ?></b><br><?= htmlspecialchars($donor['blood_group'], ENT_QUOTES) ?><br><?= htmlspecialchars($donor['address'], ENT_QUOTES) ?>");
<?php endforeach; ?>

function openEditModal(id, name, mobile, age, email, blood, address, lat, lng) {
    document.getElementById('edit_id').value = id;
    document.getElementById('edit_fullname').value = name;
    document.getElementById('edit_mobile').value = mobile;
    document.getElementById('edit_age').value = age;
    document.getElementById('edit_email').value = email;
    document.getElementById('edit_blood').value = blood;
    document.getElementById('edit_address').value = address;
    document.getElementById('edit_latitude').value = lat;
    document.getElementById('edit_longitude').value = lng;

    document.getElementById('editModal').style.display = "flex";
}

function closeEditModal() {
    document.getElementById('editModal').style.display = "none";
}
</script>

</body>
</html>