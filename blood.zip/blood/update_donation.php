<?php
include("db_connect.php"); // change to your connection file if needed
session_start();

if (isset($_POST['donor_id'])) {
    $donor_id = $_POST['donor_id'];
    $today = date('Y-m-d');

    // Update donor as unavailable for 6 months
    $sql = "UPDATE donors 
            SET last_donation_date = '$today', 
                status = 'unavailable' 
            WHERE id = '$donor_id'";

    if ($conn->query($sql) === TRUE) {
        echo "<script>
                alert('Donation recorded successfully. Donor must wait 6 months before next donation.');
                window.location.href = 'admin.php';
              </script>";
    } else {
        echo "Error updating record: " . $conn->error;
    }
}
?>
