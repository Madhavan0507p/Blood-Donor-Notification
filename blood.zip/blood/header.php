<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Blood Donation System</title>

  <style>
    /* ===== Global Styles ===== */
    body {
      margin: 0;
      padding: 0;
      font-family: "Poppins", Arial, sans-serif;
      background: linear-gradient(120deg, #ffe5e5, #fff);
      overflow-x: hidden;
      transition: background 0.5s ease-in-out;
    }

    /* ===== Header ===== */
    header {
      background: linear-gradient(90deg, #d9534f, #ff6b6b);
      color: white;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 15px 25px;
      box-shadow: 0px 3px 10px rgba(0, 0, 0, 0.2);
      position: sticky;
      top: 0;
      z-index: 100;
      animation: slideDown 0.8s ease;
    }

    .logo h1 {
      margin: 0;
      font-size: 26px;
      letter-spacing: 1px;
      font-weight: 700;
      transition: transform 0.3s ease;
    }

    .logo h1:hover {
      transform: scale(1.05);
    }

    /* ===== Navigation ===== */
    nav ul {
      list-style: none;
      margin: 0;
      padding: 0;
      display: flex;
      gap: 15px;
      align-items: center;
    }

    nav ul li {
      position: relative;
    }

    nav ul li a {
      color: white;
      text-decoration: none;
      font-size: 16px;
      padding: 8px 12px;
      border-radius: 8px;
      transition: all 0.3s ease;
    }

    nav ul li a:hover {
      background: white;
      color: #d9534f;
      box-shadow: 0 0 8px rgba(255, 255, 255, 0.6);
      transform: translateY(-2px);
    }

    /* ===== Login Button Style ===== */
    .login-btn a {
      background: white;
      color: #d9534f;
      padding: 8px 15px;
      border-radius: 8px;
      font-weight: 600;
      transition: all 0.3s ease;
      border: 2px solid transparent;
    }

    .login-btn a:hover {
      background: #d9534f;
      color: white;
      box-shadow: 0 0 12px rgba(255, 255, 255, 0.9);
      transform: scale(1.05);
      border: 2px solid white;
    }

    /* ===== Slideshow Image ===== */
    center {
      margin-top: 20px;
    }

    img {
      width: 95%;
      max-width: 1300px;
      height: 600px;
      border-radius: 20px;
      box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
      transition: transform 1s ease, box-shadow 0.5s ease;
      opacity: 1;
    }

    img:hover {
      transform: scale(1.03);
      box-shadow: 0 12px 30px rgba(217, 83, 79, 0.5);
    }

    /* ===== Fade Animation for Image ===== */
    #slideshow {
      transition: opacity 1s ease-in-out;
    }

    /* ===== Animations ===== */
    @keyframes slideDown {
      from {
        transform: translateY(-100%);
        opacity: 0;
      }
      to {
        transform: translateY(0);
        opacity: 1;
      }
    }

    /* ===== Responsive Design ===== */
    @media (max-width: 768px) {
      header {
        flex-direction: column;
        text-align: center;
      }

      nav ul {
        flex-direction: column;
        gap: 10px;
      }

      img {
        width: 90%;
        height: auto;
      }
    }
  </style>
</head>

<body>
  <header>
    <div class="logo">
      <h1>Blood Donation System</h1>
    </div>
    <nav>
      <ul>
        <li><a href="about.php">About Us</a></li>
        <li><a href="become_donor.php">Become a Donor</a></li>
        <li><a href="need_blood.php">Need Blood</a></li>
        <li><a href="contact.php">Contact Us</a></li>
        <li class="login-btn"><a href="login.php">Login</a></li>
      </ul>
    </nav>
  </header>

  <center>
    <img id="slideshow" src="img/_107317099_blooddonor976.jpg" alt="Blood Donation Image">
  </center>

  <script>
    // Array of images
    const images = [
      "img/im2.jpg",
      "img/im3.jpg",
      "img/_107317099_blooddonor976.jpg",
      "img/im4.jpg"
    ];

    let index = 0; // Track current image

    function changeImage() {
      index = (index + 1) % images.length; // Loop through images
      const imgElement = document.getElementById("slideshow");
      imgElement.style.opacity = 0;

      setTimeout(() => {
        imgElement.src = images[index];
        imgElement.style.opacity = 1;
      }, 400);
    }

    // Change image every 3 seconds (3000ms)
    setInterval(changeImage, 3000);
  </script>
</body>
</html>