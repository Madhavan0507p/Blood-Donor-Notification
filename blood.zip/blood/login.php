<!-- login.php -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Blood Donor Notification - Login</title>
  <style>
    /* --- GLOBAL LAYOUT --- */
    body {
      margin: 0;
      padding: 0;
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      background: linear-gradient(135deg, #ff4b5c, #ff758c);
      font-family: "Poppins", Arial, sans-serif;
      animation: bgMove 10s infinite alternate ease-in-out;
    }

    @keyframes bgMove {
      0% { background: linear-gradient(135deg, #ff4b5c, #ff758c); }
      50% { background: linear-gradient(135deg, #ff758c, #ff4b5c); }
      100% { background: linear-gradient(135deg, #c82333, #ff4b5c); }
    }

    /* --- LOGIN CARD --- */
    .login-container {
      background: rgba(255, 255, 255, 0.96);
      width: 360px;
      padding: 40px 35px;
      border-radius: 16px;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
      text-align: center;
      transition: all 0.3s ease;
    }

    .login-container:hover {
      transform: translateY(-4px);
      box-shadow: 0 12px 30px rgba(0, 0, 0, 0.35);
    }

    .login-container h2 {
      color: #c82333;
      font-size: 26px;
      margin-bottom: 25px;
      letter-spacing: 1px;
      font-weight: 600;
      position: relative;
    }

    .login-container h2::after {
      content: "";
      position: absolute;
      width: 70px;
      height: 3px;
      background: #c82333;
      bottom: -8px;
      left: 50%;
      transform: translateX(-50%);
      border-radius: 5px;
    }

    /* --- INPUT FIELDS --- */
    input[type="text"],
    input[type="password"] {
      width: 100%;
      padding: 12px 15px;
      margin: 12px 0;
      border: 2px solid #ff4b5c;
      border-radius: 8px;
      font-size: 15px;
      outline: none;
      background-color: #fff;
      box-sizing: border-box;
      transition: all 0.3s ease;
      display: block;
    }

    input[type="text"]:focus,
    input[type="password"]:focus {
      border-color: #c82333;
      box-shadow: 0 0 10px rgba(200, 35, 51, 0.4);
    }

    /* --- BUTTON STYLING --- */
    button {
      width: 100%;
      padding: 12px;
      background: linear-gradient(135deg, #c82333, #ff4b5c);
      color: #fff;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      font-weight: 600;
      letter-spacing: 1px;
      font-size: 16px;
      margin-top: 10px;
      transition: all 0.3s ease;
      box-shadow: 0 5px 15px rgba(200, 35, 51, 0.4);
    }

    button:hover {
      background: linear-gradient(135deg, #ff4b5c, #c82333);
      transform: scale(1.05);
      box-shadow: 0 8px 22px rgba(200, 35, 51, 0.6);
    }

    /* --- ERROR MESSAGE --- */
    .error {
      color: #ff0000;
      font-weight: 500;
      text-align: center;
      margin-top: 12px;
      animation: shake 0.4s ease-in-out;
    }

    @keyframes shake {
      0%, 100% { transform: translateX(0); }
      20%, 60% { transform: translateX(-8px); }
      40%, 80% { transform: translateX(8px); }
    }

    /* --- FOOTER --- */
    .footer {
      text-align: center;
      font-size: 12px;
      color: #555;
      margin-top: 20px;
      opacity: 0.8;
      transition: color 0.3s ease;
    }

    .footer:hover {
      opacity: 1;
      color: #c82333;
    }

    /* --- RESPONSIVE DESIGN --- */
    @media (max-width: 420px) {
      .login-container {
        width: 90%;
        padding: 30px 20px;
      }

      .login-container h2 {
        font-size: 22px;
      }

      input[type="text"],
      input[type="password"],
      button {
        font-size: 14px;
      }
    }
  </style>
</head>
<body>
  <div class="login-container">
    <h2>Blood Donor Login</h2>
    <form method="POST" action="login_action.php">
      <input type="text" name="username" placeholder="Username" required />
      <input type="password" name="password" placeholder="Password" required />
      <button type="submit">Login</button>
    </form>

    <?php
      if (isset($_GET['error'])) {
        echo '<div class="error">Invalid username or password</div>';
      }
    ?>

    <div class="footer">Donor Notification System © 2025</div>
  </div>
</body>
</html>