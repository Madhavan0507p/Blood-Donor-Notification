<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Become a Donor</title>
  <style>
    /* ------------------ Global ------------------ */
    body {
      font-family: "Poppins", Arial, sans-serif;
      margin: 0;
      padding: 0;
      background: linear-gradient(135deg, #fce7e7, #fff);
      color: #333;
    }

    header {
      background-color: #d9534f;
      color: white;
      padding: 25px 0;
      text-align: center;
      font-size: 1.8rem;
      font-weight: 600;
      box-shadow: 0 3px 12px rgba(0, 0, 0, 0.15);
    }

    .container {
      max-width: 900px;
      margin: 50px auto;
      background: #fff;
      border-radius: 16px;
      padding: 40px 50px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
      animation: fadeInUp 0.9s ease forwards;
    }

    @keyframes fadeInUp {
      0% {
        opacity: 0;
        transform: translateY(25px);
      }
      100% {
        opacity: 1;
        transform: translateY(0);
      }
    }

    h2 {
      text-align: center;
      color: #d9534f;
      font-weight: 600;
      margin-bottom: 40px;
      position: relative;
    }

    h2::after {
      content: "";
      display: block;
      width: 70px;
      height: 3px;
      background: #d9534f;
      margin: 10px auto 0;
      border-radius: 3px;
    }

    /* ------------------ Form Layout ------------------ */
    form {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
      gap: 25px;
    }

    /* ------------------ Input Field Container ------------------ */
    .input-container {
      position: relative;
    }

    .input-container input,
    .input-container select {
      width: 100%;
      padding: 14px 14px;
      font-size: 16px;
      border: 2px solid #e4e4e4;
      border-radius: 10px;
      outline: none;
      background: #fff;
      transition: all 0.3s ease;
    }

    .input-container input:hover,
    .input-container select:hover {
      border-color: #d9534f;
      box-shadow: 0 0 10px rgba(217, 83, 79, 0.15);
    }

    .input-container input:focus,
    .input-container select:focus {
      border-color: #d9534f;
      box-shadow: 0 0 12px rgba(217, 83, 79, 0.25);
      background-color: #fffaf9;
    }

    .input-container label {
      position: absolute;
      top: -8px;
      left: 14px;
      background-color: white;
      color: #d9534f;
      font-size: 13px;
      font-weight: 600;
      padding: 0 6px;
    }

    /* ------------------ Buttons ------------------ */
    button {
      width: 100%;
      background-color: #d9534f;
      color: #fff;
      border: none;
      border-radius: 10px;
      padding: 14px;
      font-size: 17px;
      cursor: pointer;
      transition: all 0.3s ease;
      font-weight: 500;
    }

    button:hover {
      background-color: #c9302c;
      transform: translateY(-2px);
      box-shadow: 0 6px 15px rgba(217, 83, 79, 0.3);
    }

    .full-width {
      grid-column: span 3;
    }

    /* ------------------ Success Modal ------------------ */
    #successModal {
      display: none;
      position: fixed;
      inset: 0;
      background: rgba(0, 0, 0, 0.5);
      justify-content: center;
      align-items: center;
      z-index: 100;
    }

    #successModal div {
      background: white;
      padding: 35px 45px;
      border-radius: 12px;
      text-align: center;
      animation: pop 0.4s ease;
      box-shadow: 0 0 25px rgba(0, 0, 0, 0.2);
    }

    @keyframes pop {
      from {
        transform: scale(0.7);
        opacity: 0;
      }
      to {
        transform: scale(1);
        opacity: 1;
      }
    }

    #successModal h3 {
      color: #28a745;
      margin-bottom: 12px;
    }

    #successModal button {
      background-color: #28a745;
    }

    #successModal button:hover {
      background-color: #218838;
    }

    /* ------------------ Responsive ------------------ */
    @media (max-width: 600px) {
      .container {
        padding: 25px;
      }
      h2 {
        font-size: 22px;
      }
    }
  </style>

  <script>
    function openLocationPicker() {
      let locationWindow = window.open(
        "location_picker.php",
        "_blank",
        "width=800,height=600"
      );
      window.addEventListener(
        "message",
        function (event) {
          if (event.origin !== window.location.origin) return;
          let data = event.data;
          if (data.lat && data.lng) {
            document.getElementById("latitude").value = data.lat;
            document.getElementById("longitude").value = data.lng;
          }
        },
        false
      );
    }

    function validateForm() {
      let name = document.forms["donorForm"]["fullname"].value.trim();
      let mobile = document.forms["donorForm"]["mobile"].value.trim();
      let email = document.forms["donorForm"]["email"].value.trim();
      let age = document.forms["donorForm"]["age"].value.trim();
      let gender = document.forms["donorForm"]["gender"].value;
      let bloodGroup = document.forms["donorForm"]["blood_group"].value;
      let address = document.forms["donorForm"]["address"].value.trim();
      let latitude = document.forms["donorForm"]["latitude"].value;
      let longitude = document.forms["donorForm"]["longitude"].value;

      let namePattern = /^[A-Za-z ]+$/;
      let mobilePattern = /^[6-9]\d{9}$/;
      let emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

      if (name === "") {
        alert("Full Name is required");
        return false;
      }
      if (!namePattern.test(name)) {
        alert("Full Name must contain letters only (A-Z or a-z)");
        return false;
      }
      if (!mobilePattern.test(mobile)) {
        alert("Enter a valid 10-digit mobile number starting with 6-9");
        return false;
      }
      if (!emailPattern.test(email)) {
        alert("Enter a valid email address");
        return false;
      }
      if (isNaN(age) || age < 18 || age > 65) {
        alert("Age must be between 18 and 65");
        return false;
      }
      if (gender === "") {
        alert("Please select a gender");
        return false;
      }
      if (bloodGroup === "") {
        alert("Please select a blood group");
        return false;
      }
      if (address === "") {
        alert("Address is required");
        return false;
      }
      if (latitude === "" || longitude === "") {
        alert("Please set your location.");
        return false;
      }

      showSuccessModal();
      return false;
    }

    function showSuccessModal() {
      document.getElementById("successModal").style.display = "flex";
    }

    function closeSuccessModal() {
      document.getElementById("successModal").style.display = "none";
    }
  </script>
</head>
<body>
  <header>Become a Donor</header>

  <div class="container">
    <h2>Register as a Blood Donor</h2>

    <form
      name="donorForm"
      action="store_donor.php"
      method="post"
      onsubmit="return validateForm()"
    >
      <!-- Full Name -->
      <div class="input-container">
        <label>Full Name</label>
        <input type="text" name="fullname" required />
      </div>

      <!-- Mobile Number -->
      <div class="input-container">
        <label>Mobile No</label>
        <input type="text" name="mobile" required />
      </div>

      <!-- Age -->
      <div class="input-container">
        <label>Age</label>
        <input type="number" name="age" required />
      </div>

      <!-- Email -->
      <div class="input-container">
        <label>Email ID</label>
        <input type="email" name="email" required />
      </div>

      <!-- Gender -->
      <div class="input-container">
        <label>Gender</label>
        <select name="gender" required>
          <option value="">Select Gender</option>
          <option value="Male">Male</option>
          <option value="Female">Female</option>
          <option value="Other">Other</option>
        </select>
      </div>

      <!-- Blood Group -->
      <div class="input-container">
        <label>Blood Group</label>
        <select name="blood_group" required>
          <option value="">Select Blood Group</option>
          <option value="A+">A+</option>
          <option value="A-">A-</option>
          <option value="B+">B+</option>
          <option value="B-">B-</option>
          <option value="O+">O+</option>
          <option value="O-">O-</option>
          <option value="AB+">AB+</option>
          <option value="AB-">AB-</option>
        </select>
      </div>

      <!-- Address -->
      <div class="input-container full-width">
        <label>Address</label>
        <input type="text" name="address" required />
      </div>

      <!-- Location -->
      <div class="full-width">
        <button type="button" onclick="openLocationPicker()">📍 Set Location</button>
      </div>

      <!-- Submit -->
      <div class="full-width">
        <button type="submit">✅ Submit</button>
      </div>

      <!-- Hidden Fields -->
      <input type="hidden" id="latitude" name="latitude" />
      <input type="hidden" id="longitude" name="longitude" />
    </form>
  </div>

  <!-- Success Modal -->
  <div id="successModal">
    <div>
      <h3>🎉 Registration Successful!</h3>
      <p>Thank you for becoming a blood donor ❤️</p>
      <button onclick="closeSuccessModal()">Close</button>
    </div>
  </div>
</body>
</html>
